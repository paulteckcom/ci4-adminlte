<?php 
if(is_array($favorites) && count($favorites) > 0):
foreach($favorites as $v):
?>
<tr>
	<td><button class="btn btn-danger btn-xs mr-2" onclick="deleteFavorite(<?php echo $v['marketId'];?>)"><i class="fas fa-trash-alt"></i></button><a href="<?= site_url('trade');?>?market=<?php echo $v['pair'];?>"><strong><?php echo $v['pair'];?></strong></a></td>
	<td><?php echo $v['price'];?></td>
	<td class="<?php echo $v['changeCss']['color'];?>"><small class="mr-1"><i class="fas <?= $v['changeCss']['icon'];?>"></i></small><?php echo $v['change'];?> %</td>
	<td><?php echo $v['high'];?></td>
	<td><?php echo $v['low'];?></td>
	<td><?php echo $v['volume'] . " " . $v['market'];?></td>
	<td><span class="<?php echo $v['ratioClass'];?>"><?php echo $v['ratio'];?></span></td>
</tr>
<?php
endforeach;
endif;
?>