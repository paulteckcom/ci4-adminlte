<div class="card">
	<div class="card-body">
		<div class="form-row align-items-center">
		    <div class="col-auto">
		    	<?php echo form_dropdown('pair', $markets, '' , 'class="form-control select2" id="pair_id"');?>
		    </div>
			<div class="col-auto">
				<button type="submit" class="btn btn-primary" id="addButton" onclick="addToFavorites()">Add</button>
				<?php 
				if(isset($apiData['secret'])) :
				?>
				<button type="submit" class="btn btn-warning" id="tradeButton" onclick="goToTrade()">Trade</button>
				<?php 
				endif;
				?>
			</div>
		</div>
	</div>
</div>
<div class="responsive-lists">
<div class="row" id="listMobile">
	<?php 
  	if(is_array($favorites) && count($favorites) > 0):
  	foreach($favorites as $v):
  	?>
		<div class="col-lg-3 col-6">
	        <!-- small card -->
	        <div class="small-box <?php echo $v['changeCss']['bg'];?>">
	          <div class="inner">
	            <h4>
	            	<a href="<?= site_url('trade');?>?market=<?php echo $v['pair'];?>"><?php echo $v['pair'];?></a><br />
	            	<strong><?php echo $v['price'];?></strong><br />
	            	<small><span class="mr-1"><i class="fas <?= $v['changeCss']['icon'];?>"></i></span><?php echo $v['change'];?> %</small>
	            </h4>

	            <h5>
	            	[<span class="<?php echo $v['ratioRes'];?>"><?php echo $v['ratio'];?></span>]
	          	</h5>
	          </div>
	          <div class="icon">
	            <i class="fas fa-shopping-cart"></i>
	          </div>
	          <div class="small-box-footer">
				<button class="btn btn-sm btn-danger delete"><i class="fas fa-trash-alt"></i></button>
	          </div>
	        </div>
	    </div>
		<!-- /.info-box -->
    <?php
    endforeach;
    endif;
    ?>
</div>
</div>
<div class="card favorites-lists">
	<div class="card-body p-0">
		<table class="table table-striped">
          <thead>
            <tr>
              <th>Pair</th>
              <th>Last</th>
              <th>24h Change</th>
              <th>High</th>
              <th>Low</th>
              <th>Volume</th>
              <th style="width: 50px;">Buy/Sell</th>
            </tr>
          </thead>
          <tbody id="coinlist">
          	<?php 
          	if(is_array($favorites) && count($favorites) > 0):
          		foreach($favorites as $v):
          	?>
            <tr>
            	<td><button class="btn btn-danger btn-xs mr-2" onclick="deleteFavorite(<?php echo $v['marketId'];?>)"><i class="fas fa-trash-alt"></i></button><a href="<?= site_url('trade');?>?market=<?php echo $v['pair'];?>"><strong><?php echo $v['pair'];?></strong></a></td>
            	<td><?php echo $v['price'];?></td>
            	<td class="<?php echo $v['changeCss']['color'];?>"><small class="mr-1"><i class="fas <?= $v['changeCss']['icon'];?>"></i></small><?php echo $v['change'];?> %</td>
            	<td><?php echo $v['high'];?></td>
            	<td><?php echo $v['low'];?></td>
            	<td><?php echo $v['volume'] . " " . $v['market'];?></td>
            	<td><span class="<?php echo $v['ratioClass'];?>"><?php echo $v['ratio'];?></span></td>
            </tr>
            <?php
            	endforeach;
            endif;
            ?>
          </tbody>
        </table>
	</div>
</div>